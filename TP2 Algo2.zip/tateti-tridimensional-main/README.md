# tateti-tridimensional
tp2 algoritmos y programacion 
